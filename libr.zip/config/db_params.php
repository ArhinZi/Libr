<?php

return array(
			'host' => 'localhost',
			'dbname' => 'arhin',
			'user' => 'root',
			'password' => '',
);