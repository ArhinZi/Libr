<?php
return array(
	
	'libr/index.php/log/add' => 'home/addlog',
	'libr/index.php/log' => 'home/log',
	
	'libr/index.php/books/add' => 'home/addbook',
	'libr/index.php/books/edit/([0-9]+)' => 'home/editbook/$1',
	'libr/index.php/books/del/([0-9]+)' => 'home/delbook/$1',
	'libr/index.php/books/([0-9]+)' => 'home/book/$1',
	'libr/index.php/books' => 'home/books',
	
	'libr/index.php/authors' => 'home/authors',
	
	'libr/index.php/tags' => 'home/tags',
	
	'libr/index.php/([-_a-z0-9]+)' => '404',

	);