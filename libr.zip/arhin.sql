-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Май 28 2017 г., 02:58
-- Версия сервера: 10.1.21-MariaDB
-- Версия PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `arhin`
--

DELIMITER $$
--
-- Процедуры
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_book` (`named` VARCHAR(50), `aud` INTEGER)  BEGIN
DECLARE aid INTEGER;
SELECT id into aid FROM auditory WHERE auditory.num = aud;
INSERT INTO book SET book.name = named, book.auditory_id = aid;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `del_book` (IN `named` VARCHAR(50))  BEGIN
DELETE FROM book WHERE book.name=named;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sel_book` (OUT `a` INT)  SELECT count(*) into a FROM log WHERE id>5$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `auditory`
--

CREATE TABLE `auditory` (
  `id` int(11) NOT NULL,
  `num` int(11) NOT NULL,
  `cathedra_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `auditory`
--

INSERT INTO `auditory` (`id`, `num`, `cathedra_id`) VALUES
(12, 510, 1),
(13, 511, 1),
(14, 512, 1),
(15, 410, 2),
(16, 411, 2),
(17, 412, 2),
(18, 310, 3),
(19, 311, 3),
(20, 312, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `author`
--

CREATE TABLE `author` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `author`
--

INSERT INTO `author` (`id`, `name`) VALUES
(7, 'Андерсон'),
(4, 'Берман'),
(20, 'Второй'),
(9, 'Гаевский'),
(11, 'Глейзер'),
(16, 'Дорофеев'),
(13, 'Ефимов'),
(8, 'Заболоцкий'),
(14, 'Коровкин'),
(1, 'Ньютон'),
(15, 'Пекарский'),
(19, 'Первый'),
(17, 'Потапов'),
(18, 'Розов'),
(2, 'Селезнев'),
(12, 'Солодовников'),
(5, 'Страуструп'),
(21, 'Тритий'),
(10, 'Фильчакова'),
(6, 'Шилдт'),
(3, 'Яворский');

-- --------------------------------------------------------

--
-- Структура таблицы `book`
--

CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `auditory_id` int(11) NOT NULL,
  `Availability` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `book`
--

INSERT INTO `book` (`id`, `name`, `auditory_id`, `Availability`) VALUES
(1, 'Молекулярная физика', 20, 1),
(2, 'Справочное руководство по физике', 19, 1),
(3, 'Сборник задач по курсу математического анализа', 16, 0),
(4, 'Алгоритмы с++', 13, 0),
(5, 'С++ Базовый курс', 14, 0),
(6, 'Дискретная математика', 12, 0),
(7, 'Матан', 14, 1),
(8, 'Пособие по математике', 15, 1),
(9, 'Основы програмирования', 12, 1),
(10, 'Математический анализ', 14, 1),
(11, 'Краткий курс аналитической геометрии', 17, 1),
(12, 'Введение в линечную алгебру и линейное программиро', 12, 1),
(13, 'Алгебра и начала анализа', 15, 1),
(14, 'Справочник по элементарной математике', 18, 1),
(15, 'Информатика 7-10кл', 12, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `book_author`
--

CREATE TABLE `book_author` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `book_author`
--

INSERT INTO `book_author` (`id`, `book_id`, `author_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 2, 3),
(4, 3, 4),
(5, 4, 5),
(6, 5, 6),
(7, 7, 8),
(8, 2, 3),
(9, 2, 2),
(10, 15, 9),
(11, 14, 10),
(12, 13, 11),
(13, 12, 12),
(14, 11, 13),
(15, 10, 14),
(16, 9, 15),
(17, 8, 16),
(18, 8, 17),
(19, 8, 18);

-- --------------------------------------------------------

--
-- Структура таблицы `book_tag`
--

CREATE TABLE `book_tag` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `book_tag`
--

INSERT INTO `book_tag` (`id`, `book_id`, `tag_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 5),
(5, 2, 2),
(6, 2, 6),
(7, 2, 7),
(8, 3, 10),
(9, 3, 13),
(10, 4, 11),
(11, 4, 9),
(12, 4, 8),
(13, 5, 9),
(14, 5, 8),
(15, 6, 10),
(16, 6, 11),
(17, 7, 3),
(18, 7, 10),
(19, 8, 10),
(21, 8, 16),
(22, 9, 8),
(23, 10, 3),
(24, 10, 10),
(25, 11, 5),
(27, 12, 8),
(28, 12, 10),
(29, 13, 18),
(30, 13, 10),
(31, 14, 6),
(32, 14, 10),
(33, 15, 18),
(34, 15, 14),
(35, 15, 8);

-- --------------------------------------------------------

--
-- Структура таблицы `cathedra`
--

CREATE TABLE `cathedra` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `cathedra`
--

INSERT INTO `cathedra` (`id`, `name`) VALUES
(1, 'Информатики, программной инженерии и экономической кибернетики'),
(2, 'Математики'),
(3, 'Физики');

-- --------------------------------------------------------

--
-- Структура таблицы `log`
--

CREATE TABLE `log` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `num_lib_card` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `log_type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `log`
--

INSERT INTO `log` (`id`, `book_id`, `num_lib_card`, `time`, `log_type_id`) VALUES
(1, 4, 12, '2017-05-27 23:47:14', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `log_type`
--

CREATE TABLE `log_type` (
  `id` int(11) NOT NULL,
  `type` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `log_type`
--

INSERT INTO `log_type` (`id`, `type`) VALUES
(2, 'вернул'),
(1, 'взял');

-- --------------------------------------------------------

--
-- Структура таблицы `tag`
--

CREATE TABLE `tag` (
  `id` int(11) NOT NULL,
  `tag` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `tag`
--

INSERT INTO `tag` (`id`, `tag`) VALUES
(11, 'Алгоритмы'),
(4, 'Астрономия'),
(5, 'Атом'),
(16, 'Для поступающих'),
(18, 'Для школы'),
(14, 'Информатика'),
(10, 'Математика(алгебра, геометрия)'),
(1, 'Молекула'),
(8, 'Программирование'),
(9, 'С++'),
(7, 'Самообразование'),
(13, 'Сборник задач'),
(3, 'Сложно'),
(6, 'Справочник'),
(99, 'Странно'),
(21, 'Таг'),
(19, 'Тег'),
(2, 'Физика');

--
-- Триггеры `tag`
--
DELIMITER $$
CREATE TRIGGER `1` AFTER INSERT ON `tag` FOR EACH ROW Insert into author set author.name = 'asd'
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `2` BEFORE UPDATE ON `tag` FOR EACH ROW set New.tag = md5(New.tag)
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `3` AFTER DELETE ON `tag` FOR EACH ROW delete from author where author.name = 'asd'
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `11` BEFORE INSERT ON `tag` FOR EACH ROW IF CHAR_LENGTH(new.tag)<2 THEN
KILL QUERY CONNECTION_ID();
end if
$$
DELIMITER ;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `auditory`
--
ALTER TABLE `auditory`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `num` (`num`),
  ADD KEY `ad1` (`cathedra_id`);

--
-- Индексы таблицы `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`),
  ADD KEY `3` (`auditory_id`);

--
-- Индексы таблицы `book_author`
--
ALTER TABLE `book_author`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ba1` (`book_id`),
  ADD KEY `ba2` (`author_id`);

--
-- Индексы таблицы `book_tag`
--
ALTER TABLE `book_tag`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bt1` (`book_id`),
  ADD KEY `bt2` (`tag_id`);

--
-- Индексы таблицы `cathedra`
--
ALTER TABLE `cathedra`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `1` (`log_type_id`),
  ADD KEY `2` (`book_id`);

--
-- Индексы таблицы `log_type`
--
ALTER TABLE `log_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `type` (`type`);

--
-- Индексы таблицы `tag`
--
ALTER TABLE `tag`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tag` (`tag`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `auditory`
--
ALTER TABLE `auditory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT для таблицы `author`
--
ALTER TABLE `author`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=174;
--
-- AUTO_INCREMENT для таблицы `book`
--
ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT для таблицы `book_author`
--
ALTER TABLE `book_author`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;
--
-- AUTO_INCREMENT для таблицы `book_tag`
--
ALTER TABLE `book_tag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;
--
-- AUTO_INCREMENT для таблицы `cathedra`
--
ALTER TABLE `cathedra`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;
--
-- AUTO_INCREMENT для таблицы `log`
--
ALTER TABLE `log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `log_type`
--
ALTER TABLE `log_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `tag`
--
ALTER TABLE `tag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `auditory`
--
ALTER TABLE `auditory`
  ADD CONSTRAINT `ad1` FOREIGN KEY (`cathedra_id`) REFERENCES `cathedra` (`id`);

--
-- Ограничения внешнего ключа таблицы `book`
--
ALTER TABLE `book`
  ADD CONSTRAINT `3` FOREIGN KEY (`auditory_id`) REFERENCES `auditory` (`id`);

--
-- Ограничения внешнего ключа таблицы `book_author`
--
ALTER TABLE `book_author`
  ADD CONSTRAINT `ba1` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`),
  ADD CONSTRAINT `ba2` FOREIGN KEY (`author_id`) REFERENCES `author` (`id`);

--
-- Ограничения внешнего ключа таблицы `book_tag`
--
ALTER TABLE `book_tag`
  ADD CONSTRAINT `bt1` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`),
  ADD CONSTRAINT `bt2` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`id`);

--
-- Ограничения внешнего ключа таблицы `log`
--
ALTER TABLE `log`
  ADD CONSTRAINT `1` FOREIGN KEY (`log_type_id`) REFERENCES `log_type` (`id`),
  ADD CONSTRAINT `2` FOREIGN KEY (`book_id`) REFERENCES `book` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
